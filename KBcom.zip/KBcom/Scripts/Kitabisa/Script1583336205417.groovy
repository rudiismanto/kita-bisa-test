import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('kitabisa.com')

WebUI.scrollToElement(findTestObject('Object Repository/copy_bantu_siapa_hari_ini'), 0)

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/button_Kategori'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/option_Bantuan_Medis _Kesehatan'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/span_Terkumpul'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/button_DONASI SEKARANG'))

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/amount_10k'))

WebUI.click(findTestObject('Object Repository/VA_BCA'))

WebUI.setText(findTestObject('Object Repository/field_fullname'), 'automation rudi')

WebUI.delay(1)

WebUI.setText(findTestObject('Object Repository/field_email'), 'automationrudi@mailinator.com')

WebUI.click(findTestObject('Object Repository/button_LANJUTKAN PEMBAYARAN'))

WebUI.delay(1)

WebUI.verifyElementPresent(findTestObject('Object Repository/image_selamat'), 0)

WebUI.delay(1)

WebUI.click(findTestObject('Object Repository/btn_x'))

WebUI.delay(2)

WebUI.scrollToElement(findTestObject('Object Repository/copy_mencapai_target_donasi'), 0)

WebUI.click(findTestObject('Object Repository/btn_kembali_ke_pelanggan'))

WebUI.delay(2)

WebUI.closeBrowser()

